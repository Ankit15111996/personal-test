import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginObserverService } from 'src/app/services/login-observer.service';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit {
  isLogin: boolean = false;
  user = '';

  constructor(
    public login: LoginService,
    private observerService: LoginObserverService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.isLogin = this.login.isLoggedIn();
    this.user = this.login.getUser().username;
    console.log(this.user);
    this.login.loginStatusSubject.asObservable().subscribe((data) => {
      this.isLogin = this.login.isLoggedIn();
      this.user = this.login.getUser().username;
    });

    // this.observerService.isUserLoggedIn.subscribe((data)=>{
    //   this.isLogin=data
    // });
    // this.observerService.getUserName().subscribe((data)=>{
    //   this.username

    // });
    // console.log("username in toolbar is ", this.username)
  }
  logout() {

    this.login.logout();
    this.login.loginStatusSubject.next(false);
    this.router.navigate(['login']);

    // this.observerService.isUserLoggedIn.next(false);
    // this.router.navigate(['/login']);
  }
  // home() {
  //   this.router.navigate(['/home'])
  // }
  // login1(){
  //   this.router.navigate(['/login'])

  // }
}
