import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class LoginObserverService {
  isUserLoggedIn = new BehaviorSubject(false);
  messageSource = new BehaviorSubject<String>('');
  currentMessage = this.messageSource.asObservable();

  setUserName(data: String) {
    this.messageSource.next(data);
  }

  getUserName(){
    return this.currentMessage;
  }

  constructor() {}
}
