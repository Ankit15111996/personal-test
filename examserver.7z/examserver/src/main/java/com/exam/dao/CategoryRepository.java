package com.exam.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exam.entity2.Category;

public interface CategoryRepository  extends JpaRepository<Category,Long>{

}
